/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author estuam
 */
public class Paquete {
    String codigo;
    String destino;
    double peso;
    boolean asegurado;

    public Paquete(String codigo, String destino, double peso, boolean asegurado) {
        this.codigo = codigo;
        this.destino = destino;
        this.peso = peso;
        this.asegurado = asegurado;
    }

    public Paquete(String codigo, String destino) {
        this(codigo, destino, 1.0, false);
    }

    public Paquete(String codigo) {
        this(codigo, "Por asignar");
    }

    public void mostrarInformacion() {
        System.out.println(this.codigo + " -> " + this.destino + " | " + this.peso + " kg | asegurado: " + this.asegurado);
    }

    public void actualizarPeso(double peso) {
       this.peso = peso;
    }

    public double calcularCosto() {
        double costoBase = this.peso * 5000;
        if (this.asegurado) {
            costoBase += 8000;
        }
        return costoBase;
    }

    public double calcularCosto(double tarifaPorKilo) {
        double costoBase = this.peso * tarifaPorKilo;
        if (this.asegurado) {
            costoBase += 8000;
        }
        return costoBase;
    }
}
